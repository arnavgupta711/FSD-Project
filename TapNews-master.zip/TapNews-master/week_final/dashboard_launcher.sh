#!/bin/bash
cd dashboard
python server.py
