
class_map = {
  '1' : 'Colleges & Schools',
  '2' : 'Environmental',
  '3' : 'World',
  '4' : 'Entertainment',
  '5' : 'Media',
  '6' : 'Politics & Government',
  '7' : 'Regional News',
  '8' : 'Religion',
  '9' : 'Sports',
  '10' : 'Technology',
  '11' : 'Traffic',
  '12' : 'Weather',
  '13' : 'Economic & Corp',
  '14' : 'Advertisements',
  '15' : 'Crime',
  '16' : 'Other',
  '17' : 'Magazine'
}