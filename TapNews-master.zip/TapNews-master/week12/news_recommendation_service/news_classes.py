classes = [
    "Colleges & Schools",
    "Environmental",
    "World",
    "Entertainment",
    "Media",
    "Politics & Government",
    "Regional News",
    "Religion",
    "Sports",
    "Technology",
    "Traffic",
    "Weather",
    "Economic & Corp",
    "Advertisements",
    "Crime",
    "Other",
    "Magazine"
]