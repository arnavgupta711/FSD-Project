# week12
+ Fix page refresh
+ Add more tag on newscard
+ Refactor with configuration

### QA

+ run shell, click enter to kill all jobs
chmod 755 xx.sh
sudo ./xx.sh