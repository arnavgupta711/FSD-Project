# TapNews

## About

This is a web app that:
- Built with React.
- Collect news from multiple news sources and apply ML: tf-idf to remove duplicates all & tensorflow CNN to predict news topic,
- Service Oriented, multiple backend servces commucating through jsonrpc, 
- Automatically recommend news based on user click logs. 

Click here to see the [demo](http://34.214.18.41:3000/)
- You can either sign up or use my account mwangxx@gmail.com / 12345678 to login.
- Because the demo runs on Amazon free tier instance, it is not fully functioning in terms of model traning and news recommendation.

